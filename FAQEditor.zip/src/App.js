import React from 'react';
import FAQEditor from './components/FAQEditor';

function App() {
  return (
    <div className="App">
      <FAQEditor />
    </div>
  );
}

export default App;
